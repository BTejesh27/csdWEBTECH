<?php
session_start(); 
include 'connect.php';

// Check if the session value exists
if (!isset($_SESSION['team_lead_mobile'])) {
    header("Location: studentlogin.php");
    exit;
}

// Handle score submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mobile_number = $_POST['mobile_number'];
    $score = intval($_POST['score']);

    if ($score >= 0 && $score <= 15) {
        $sql = "UPDATE scores SET presentscore = COALESCE(presentscore, 0) + ? WHERE mobile_number = ?
";
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $stmt->bind_param("is", $score, $mobile_number);
            
            if ($stmt->execute()) {
                $_SESSION['message'] = "Score submitted successfully!";
                header("Location: studentlogin.php");
                exit;
            } else {
                $error = "Error executing statement: " . $stmt->error; // Debugging output
            }
            $stmt->close();
        } else {
            $error = "Error preparing statement: " . $conn->error; // Debugging output
        }
    } else {
        $error = "Invalid score. Please enter a number between 0 and 15.";
    }
}

// Fetching scores
$sql = "SELECT mobile_number, teamlead, presentscore FROM scores WHERE status = 1 AND qualify = 1 AND r1 IS NOT NULL AND r2 IS NOT NULL AND r3 IS NOT NULL";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Presentation Scoring</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #00b4db, #0083b0);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: inline-block;
            margin-right: 10px;
            font-weight: bold;
        }
        .form-group input[type="number"] {
            width: 60px;
            padding: 5px;
        }
        .form-group button {
            padding: 5px 10px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #218838;
        }
        .message { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Project Presentation Scoring</h1>
        
        <?php
        if (isset($_SESSION['message'])) {
            echo "<p class='message'>" . htmlspecialchars($_SESSION['message']) . "</p>";
            unset($_SESSION['message']);
        }
        if (isset($error)) echo "<p class='error'>" . htmlspecialchars($error) . "</p>";
        ?>

        <table>
            <thead>
                <tr>
                    <th>Team Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['teamlead']) . "</td>";
                        echo "<td>";
                        echo "<form method='POST' action='" . htmlspecialchars($_SERVER['PHP_SELF']) . "'>";
                        echo "<input type='hidden' name='mobile_number' value='" . htmlspecialchars($row['mobile_number']) . "'>";
                        echo "<div class='form-group'>";
                        echo "<label for='score-" . htmlspecialchars($row['mobile_number']) . "'>Score (0-15):</label>";
                        echo "<input type='number' id='score-" . htmlspecialchars($row['mobile_number']) . "' name='score' min='0' max='15' required>";
                        echo "<button type='submit'>Submit</button>";
                        echo "</div>";
                        echo "</form>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='2'>No teams found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
$conn->close();
?>
