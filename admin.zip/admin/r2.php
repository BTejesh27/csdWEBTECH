

<?php
session_start();

if (!isset($_SESSION['login_id']) || $_SESSION['login_id'] !== '2024CSD') {
    header("Location: r2login.php"); 
    exit;
}


include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_score'])) {
    $mobile_number = $_POST['mobile_number'];
    $score = intval($_POST['score']);
    
    if ($score >= 0 && $score <= 200) {
        $sql = "UPDATE scores SET r2 = ? WHERE mobile_number = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $score, $mobile_number);
        if ($stmt->execute()) {
            $message = "Score updated successfully.";
        } else {
            $error = "Error updating score: " . $conn->error;
        }
        $stmt->close();
    } else {
        $error = "Invalid score. Please enter a number between 0 and 200.";
    }
}

$sql = "SELECT mobile_number, teamlead, r2 FROM scores ORDER BY teamlead";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Round 2 Scoring</title>    <style>
        table {
            margin: 20px auto;
            justify-content: center;

            border-collapse: collapse;
            width: 50%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        input[type="number"] {
            width: 60px;
        }
        .message { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <h1  style=" display:flex;  justify-content: center" >Participant Scoring round 2</h1>
    <?php
    if (isset($message)) echo "<p class='message'>$message</p>";
    if (isset($error)) echo "<p class='error'>$error</p>";
    ?>

    <table>
        <thead>
            <tr>
                <th>Team Name</th>
                <th>Current Score (r2)</th>
                <th>New Score (0-200)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['teamlead']) . "</td>";
                    echo "<td>" . ($row['r2'] !== null ? $row['r2'] : 'Not set') . "</td>";
                    echo "<td>";
                    echo "<form method='POST' action=''>";
                    echo "<input type='hidden' name='mobile_number' value='" . $row['mobile_number'] . "'>";
                    echo "<input type='number' name='score' min='0' max='200' required>";
                    echo "</td>";
                    echo "<td><input type='submit' name='submit_score' value='Save Score'></td>";
                    echo "</form>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No participants found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>