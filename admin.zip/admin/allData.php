<?php
session_start();
include 'connect.php';

// Handle edit form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit'])) {
    $mobile_number = $_POST['mobile_number'];
    $teamlead = $_POST['teamlead'];
    $presentscore = $_POST['presentscore'];
    $r1 = $_POST['r1'];
    $r2 = $_POST['r2'];
    $r3 = $_POST['r3'];
    $status = $_POST['status'];
    $qualify = $_POST['qualify'];

    $sql = "UPDATE scores SET 
                teamlead = ?, 
                presentscore = ?, 
                r1 = ?, 
                r2 = ?, 
                r3 = ?, 
                status = ?, 
                qualify = ? 
            WHERE mobile_number = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siiiiisi", $teamlead, $presentscore, $r1, $r2, $r3, $status, $qualify, $mobile_number);
    
    if ($stmt->execute()) {
        echo "<script>alert('Record updated successfully');</script>";
    } else {
        echo "<script>alert('Error updating record: " . $conn->error . "');</script>";
    }
    $stmt->close();
}

// Fetch all data from the scores table
$sql = "SELECT mobile_number, teamlead, presentscore, r1, r2, r3, status, qualify FROM scores";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal - Manage Scores</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .edit-form {
            display: none;
            margin-bottom: 20px;
        }
        .edit-form input {
            margin: 5px 0;
            width: calc(100% - 12px);
            padding: 5px;
        }
        .edit-form button {
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        .edit-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Manage Scores</h1>
    <table>
        <thead>
            <tr>
                <th>Mobile Number</th>
                <th>Team Lead</th>
                <th>Present Score</th>
                <th>R1</th>
                <th>R2</th>
                <th>R3</th>
                <th>Status</th>
                <th>Qualify</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['mobile_number']); ?></td>
                        <td><?php echo htmlspecialchars($row['teamlead']); ?></td>
                        <td><?php echo htmlspecialchars($row['presentscore']); ?></td>
                        <td><?php echo htmlspecialchars($row['r1']); ?></td>
                        <td><?php echo htmlspecialchars($row['r2']); ?></td>
                        <td><?php echo htmlspecialchars($row['r3']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                        <td><?php echo htmlspecialchars($row['qualify']); ?></td>
                        <td>
                            <button onclick="showEditForm('<?php echo htmlspecialchars($row['mobile_number']); ?>', '<?php echo htmlspecialchars($row['teamlead']); ?>', '<?php echo htmlspecialchars($row['presentscore']); ?>', '<?php echo htmlspecialchars($row['r1']); ?>', '<?php echo htmlspecialchars($row['r2']); ?>', '<?php echo htmlspecialchars($row['r3']); ?>', '<?php echo htmlspecialchars($row['status']); ?>', '<?php echo htmlspecialchars($row['qualify']); ?>')">Edit</button>
                        </td>
                    </tr>
                    <?php
                }
            } else {
                echo "<tr><td colspan='9'>No data found</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="edit-form" id="edit-form">
        <h2>Edit Score</h2>
        <form id="form" action="" method="POST">
            <input type="hidden" name="mobile_number" id="edit-mobile">
            <div>
                <label for="edit-teamlead">Team Lead:</label>
                <input type="text" name="teamlead" id="edit-teamlead" required>
            </div>
            <div>
                <label for="edit-presentscore">Present Score:</label>
                <input type="number" name="presentscore" id="edit-presentscore" required>
            </div>
            <div>
                <label for="edit-r1">R1:</label>
                <input type="number" name="r1" id="edit-r1" required>
            </div>
            <div>
                <label for="edit-r2">R2:</label>
                <input type="number" name="r2" id="edit-r2" required>
            </div>
            <div>
                <label for="edit-r3">R3:</label>
                <input type="number" name="r3" id="edit-r3" required>
            </div>
            <div>
                <label for="edit-status">Status:</label>
                <input type="number" name="status" id="edit-status" required>
            </div>
            <div>
                <label for="edit-qualify">Qualify:</label>
                <input type="number" name="qualify" id="edit-qualify" required>
            </div>
            <button type="submit" name="edit">Update</button>
        </form>
    </div>

    <script>
        function showEditForm(mobile_number, teamlead, presentscore, r1, r2, r3, status, qualify) {
            document.getElementById('edit-mobile').value = mobile_number;
            document.getElementById('edit-teamlead').value = teamlead;
            document.getElementById('edit-presentscore').value = presentscore;
            document.getElementById('edit-r1').value = r1;
            document.getElementById('edit-r2').value = r2;
            document.getElementById('edit-r3').value = r3;
            document.getElementById('edit-status').value = status;
            document.getElementById('edit-qualify').value = qualify;

            document.getElementById('edit-form').style.display = 'block';
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>
