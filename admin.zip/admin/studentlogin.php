
<?php
session_start();
include 'connect.php';

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_mobile = $_POST['username'];

    $sql = "
        SELECT mobile_number 
        FROM scores 
        ORDER BY (r1 + r2 + r3) ASC 
        LIMIT 13
    ";
    $result = $conn->query($sql);

    $mobile_numbers = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $mobile_numbers[] = $row['mobile_number'];
        }
    }

    if (in_array($entered_mobile, $mobile_numbers)) {
        $_SESSION['team_lead_mobile'] = $entered_mobile;
        header("Location: studentindex.php"); 
        exit;
    } else {
        echo "You Cant Login ";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Login</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #00c6ff, #0072ff);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            max-width: 400px;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h1 {
            text-align: center;
            color: #333;
            font-size: 28px;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }
        .form-group input[type="text"] {
            width: 80%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        .form-group button {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .form-group button:hover {
            background-color: #0056b3;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 20px;
        }
        @media (max-width: 600px) {
            .container {
                margin: 20px;
                padding: 15px;
            }
            h1 {
                font-size: 24px;
            }
            .form-group input[type="text"],
            .form-group button {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Team Lead Login</h1>
        <form action="" method="POST">
            <div class="form-group">
                <label for="username">Mobile:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <button type="submit">Login</button>
            </div>
        </form>
    </div>
</body>
</html>
