<?php
session_start();

if (!isset($_SESSION['is_logged_in'])) {
    header("Location: login.php");
    exit();
}

include 'connect.php';

// Handle POST requests for updating scores
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mobile_number = $_POST['mobile_number'];
    $field = $_POST['field'];
    $value = $_POST['value'];
    $sql = "UPDATE scores SET $field = ? WHERE mobile_number = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $value, $mobile_number);
    if ($stmt->execute()) {
        echo "Success";
    } else {
        echo "Error: " . $conn->error;
    }
    $stmt->close();
    exit(); // End the script here for AJAX requests
}

// Fetch top 7 participant data based on r1, r2, r3 total score
$sql = "SELECT mobile_number, teamlead, qualify, status, (r1 + r2 + r3) AS total_score 
        FROM scores 
        ORDER BY total_score DESC 
        LIMIT 7";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .action-buttons button {
            padding: 10px 20px;
            margin: 5px 0;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .action-buttons button:disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }

        .qualified-btn.green, .present-btn.green {
            background-color: #28a745;
            color: white;
        }

        .qualified-btn.red, .present-btn.red {
            background-color: #dc3545;
            color: white;
        }

        .qualified-btn.green:hover, .present-btn.green:hover {
            background-color: #218838;
        }

        .qualified-btn.red:hover, .present-btn.red:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Portal</h1>
        <table>
            <thead>
                <tr>
                    <th>Team Name</th>
                    <th>Total Score</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $teamlead = htmlspecialchars($row['teamlead']);
                        $mobile_number = $row['mobile_number'];
                        $total_score = $row['total_score'];
                        $qualify = $row['qualify'];
                        $status = $row['status'];
                        $qualifyBtnClass = $qualify == 1 ? 'green' : 'red';
                        $presentBtnClass = $status == 1 ? 'green' : 'red';
                        ?>
                        <tr>
                            <td><?php echo $teamlead; ?></td>
                            <td><?php echo $total_score; ?></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="qualified-btn <?php echo $qualifyBtnClass; ?>" 
                                            onclick="updateScore(<?php echo $mobile_number; ?>, 'qualify', <?php echo $qualify == 1 ? 0 : 1; ?>)" 
                                            data-mobile="<?php echo $mobile_number; ?>" 
                                            data-field="qualify">
                                        Qualified
                                    </button>
                                    <button class="present-btn <?php echo $presentBtnClass; ?>" 
                                            onclick="updateScore(<?php echo $mobile_number; ?>, 'status', <?php echo $status == 1 ? 0 : 1; ?>)" 
                                            data-mobile="<?php echo $mobile_number; ?>" 
                                            data-field="status">
                                        Present
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php
                    }
                } else {
                    echo "<tr><td colspan='3'>No participants found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <script>
        function updateScore(mobile_number, field, value) {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", window.location.href, true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    if (xhr.responseText === "Success") {
                        const button = document.querySelector(`button[data-mobile="${mobile_number}"][data-field="${field}"]`);
                        if (button) {
                            if (value == 1) {
                                button.classList.add('green');
                                button.classList.remove('red');
                            } else {
                                button.classList.add('red');
                                button.classList.remove('green');
                            }
                            button.onclick = function() { updateScore(mobile_number, field, 1 - value); };
                        }
                    } else {
                        alert("Error updating score. Please try again.");
                    }
                }
            };
            xhr.send("mobile_number=" + mobile_number + "&field=" + field + "&value=" + value);
        }
    </script>
</body>
</html>
<?php
$conn->close();
?>
